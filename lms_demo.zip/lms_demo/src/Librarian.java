
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Librarian extends javax.swing.JFrame {

    Connection connection = null;
    PreparedStatement pstatement = null;
    Statement statement = null, statement1 = null;
    ResultSet resultSet = null, resultSet1 = null;
    String msAccDB = "//C://Users//orowo//Documents//LMS Database.accdb//";
    String dbURL = "jdbc:ucanaccess://" + msAccDB;

    //DefaultTableModel model = new DefaultTableModel();
    public Librarian() {
        initComponents();
        DisplayBooksTable();
    }

    private void DisplayBooksTable() {

        try {

            DefaultTableModel model = (DefaultTableModel) bookTable.getModel();
            model.setRowCount(0);

            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            connection = DriverManager.getConnection(dbURL);

            statement = connection.createStatement();

            resultSet = statement.executeQuery("SELECT * FROM Books");

            //bookTable.setModel(DbUtils.resultSetToTableModel(resultSet));
            int columns = resultSet.getMetaData().getColumnCount();
            while (resultSet.next()) {
                Object[] row = new Object[columns];

//                for (int i = 0; i <= columns; i++) {
//                    row[i - 0] = resultSet.getObject(i); // 1
//                    System.out.println("Value for column " + i + ": " + resultSet.getObject(i));
//                }
                row[0] = resultSet.getObject("bookid");
                row[1] = resultSet.getObject("title");
                row[2] = resultSet.getObject("author");
                row[3] = resultSet.getInt("copies"); // Use getInt for integer values
                row[4] = resultSet.getObject("category");
                row[5] = resultSet.getObject("isbn");
                model.addRow(row);

                //((DefaultTableModel) bookTable.getModel()).addRow(row);
                //((DefaultTableModel) bookTable.getModel()).insertRow(resultSet.getRow() - 1, row);
            }

//            while (resultSet.next()) {
//                resultSet.getString("Title");
//                resultSet.getString("Author");
//                resultSet.getInt("Copies");
//                resultSet.getString("Category");
//                resultSet.getString("ISBN");
//          
//               // System.out.println("Title: " + title + ", Author: " + author + ", Copies: " + copies + ", Category: " + category + ", ISBN: " + isbn);
//            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        headerPanel = new javax.swing.JPanel();
        headerTitle = new javax.swing.JLabel();
        Profile = new javax.swing.JTabbedPane();
        ManagePanel = new javax.swing.JPanel();
        managelbl = new javax.swing.JLabel();
        titlelbl = new javax.swing.JLabel();
        titleField = new javax.swing.JTextField();
        authorlbl = new javax.swing.JLabel();
        authorField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        copiesField = new javax.swing.JTextField();
        deleteBtn = new javax.swing.JButton();
        editBtn = new javax.swing.JButton();
        saveBtn = new javax.swing.JButton();
        categoriesField = new javax.swing.JTextField();
        categoriesLbl = new javax.swing.JLabel();
        isbnField = new javax.swing.JTextField();
        isbnLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        bookTable = new javax.swing.JTable();
        borrowedPanel = new javax.swing.JPanel();
        profilePanel = new javax.swing.JPanel();
        profileImagelbl = new javax.swing.JLabel();
        addImageBtn = new javax.swing.JButton();
        namelbl = new javax.swing.JLabel();
        emailLbl = new javax.swing.JLabel();
        accountType_lbl = new javax.swing.JLabel();
        passwordLbl = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        headerPanel.setBackground(new java.awt.Color(51, 51, 51));

        headerTitle.setBackground(new java.awt.Color(255, 255, 255));
        headerTitle.setFont(new java.awt.Font("JetBrains Mono", 0, 18)); // NOI18N
        headerTitle.setForeground(new java.awt.Color(255, 255, 255));
        headerTitle.setText("Libary Management System");

        managelbl.setFont(new java.awt.Font("JetBrains Mono", 1, 18)); // NOI18N
        managelbl.setForeground(new java.awt.Color(51, 51, 51));
        managelbl.setText("Manage  Books");

        titlelbl.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        titlelbl.setText("Book Title");

        titleField.setFont(new java.awt.Font("JetBrains Mono", 0, 12)); // NOI18N
        titleField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                titleFieldActionPerformed(evt);
            }
        });

        authorlbl.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        authorlbl.setText("Book Author");

        authorField.setFont(new java.awt.Font("JetBrains Mono", 0, 12)); // NOI18N
        authorField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                authorFieldActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        jLabel4.setText("Book Copies");

        copiesField.setFont(new java.awt.Font("JetBrains Mono", 0, 12)); // NOI18N
        copiesField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copiesFieldActionPerformed(evt);
            }
        });

        deleteBtn.setText("Delete");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });

        editBtn.setText("Edit");
        editBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editBtnActionPerformed(evt);
            }
        });

        saveBtn.setText("Save");
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });

        categoriesField.setFont(new java.awt.Font("JetBrains Mono", 0, 12)); // NOI18N
        categoriesField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                categoriesFieldActionPerformed(evt);
            }
        });

        categoriesLbl.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        categoriesLbl.setText("Categories");

        isbnField.setFont(new java.awt.Font("JetBrains Mono", 0, 12)); // NOI18N
        isbnField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isbnFieldActionPerformed(evt);
            }
        });

        isbnLabel.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        isbnLabel.setText("ISBN");

        bookTable.setAutoCreateRowSorter(true);
        bookTable.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        bookTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Title", "Author", "Copy", "Categories", "ISBN"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        bookTable.setRowHeight(28);
        bookTable.setSelectionBackground(new java.awt.Color(102, 102, 102));
        bookTable.getTableHeader().setReorderingAllowed(false);
        bookTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bookTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(bookTable);

        javax.swing.GroupLayout ManagePanelLayout = new javax.swing.GroupLayout(ManagePanel);
        ManagePanel.setLayout(ManagePanelLayout);
        ManagePanelLayout.setHorizontalGroup(
            ManagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ManagePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(saveBtn)
                .addGap(18, 18, 18)
                .addComponent(editBtn)
                .addGap(18, 18, 18)
                .addComponent(deleteBtn)
                .addGap(27, 27, 27))
            .addGroup(ManagePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ManagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(ManagePanelLayout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addGroup(ManagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(managelbl, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(ManagePanelLayout.createSequentialGroup()
                                .addGroup(ManagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(ManagePanelLayout.createSequentialGroup()
                                        .addGroup(ManagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(titlelbl, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(categoriesField, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(categoriesLbl))
                                        .addGap(61, 61, 61)
                                        .addGroup(ManagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(authorlbl, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(authorField, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(isbnField, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(isbnLabel)))
                                    .addComponent(titleField, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(60, 60, 60)
                                .addGroup(ManagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(copiesField, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 308, Short.MAX_VALUE)))
                .addContainerGap())
        );
        ManagePanelLayout.setVerticalGroup(
            ManagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ManagePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(managelbl)
                .addGap(18, 18, 18)
                .addGroup(ManagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(titlelbl)
                    .addComponent(authorlbl)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ManagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(titleField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(authorField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(copiesField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addGroup(ManagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(categoriesLbl)
                    .addComponent(isbnLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(ManagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(categoriesField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(isbnField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addGroup(ManagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(deleteBtn)
                    .addComponent(editBtn)
                    .addComponent(saveBtn))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        Profile.addTab("Manage Books", ManagePanel);

        javax.swing.GroupLayout borrowedPanelLayout = new javax.swing.GroupLayout(borrowedPanel);
        borrowedPanel.setLayout(borrowedPanelLayout);
        borrowedPanelLayout.setHorizontalGroup(
            borrowedPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 888, Short.MAX_VALUE)
        );
        borrowedPanelLayout.setVerticalGroup(
            borrowedPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 575, Short.MAX_VALUE)
        );

        Profile.addTab("Borrowed Books", borrowedPanel);

        profileImagelbl.setBackground(new java.awt.Color(153, 153, 153));
        profileImagelbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/camera_icon.png"))); // NOI18N
        profileImagelbl.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        profileImagelbl.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        addImageBtn.setText("Add Image");

        namelbl.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        namelbl.setText("Name:");

        emailLbl.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        emailLbl.setText("Email Address:");

        accountType_lbl.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        accountType_lbl.setText("Account Type:");

        passwordLbl.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        passwordLbl.setText("Password:");

        javax.swing.GroupLayout profilePanelLayout = new javax.swing.GroupLayout(profilePanel);
        profilePanel.setLayout(profilePanelLayout);
        profilePanelLayout.setHorizontalGroup(
            profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(profilePanelLayout.createSequentialGroup()
                .addGroup(profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(profilePanelLayout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(addImageBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(profilePanelLayout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(profileImagelbl, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(156, 156, 156)
                .addGroup(profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(namelbl)
                    .addComponent(emailLbl)
                    .addGroup(profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(accountType_lbl, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(passwordLbl, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(478, Short.MAX_VALUE))
        );
        profilePanelLayout.setVerticalGroup(
            profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(profilePanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(profilePanelLayout.createSequentialGroup()
                        .addComponent(namelbl)
                        .addGap(18, 18, 18)
                        .addComponent(emailLbl)
                        .addGap(18, 18, 18)
                        .addComponent(accountType_lbl))
                    .addComponent(profileImagelbl, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(passwordLbl)
                    .addComponent(addImageBtn))
                .addContainerGap(387, Short.MAX_VALUE))
        );

        Profile.addTab("Profile", profilePanel);

        javax.swing.GroupLayout headerPanelLayout = new javax.swing.GroupLayout(headerPanel);
        headerPanel.setLayout(headerPanelLayout);
        headerPanelLayout.setHorizontalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, headerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Profile)
                .addContainerGap())
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(headerTitle)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        headerPanelLayout.setVerticalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, headerPanelLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(headerTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addComponent(Profile)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(headerPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(headerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setBounds(0, 0, 916, 719);
    }// </editor-fold>//GEN-END:initComponents

    private void titleFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_titleFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_titleFieldActionPerformed

    private void authorFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_authorFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_authorFieldActionPerformed

    private void copiesFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copiesFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_copiesFieldActionPerformed

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        // TODO add your handling code here:
        int deleteRow = bookTable.getSelectedRow();

        // Check row is selected
        if (deleteRow != -1) {
            String book_id = bookTable.getValueAt(deleteRow, 0).toString();

            try {
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                connection = DriverManager.getConnection(dbURL);

                String deleteQuery = "DELETE FROM Books WHERE bookid = ?";
                // Use prepared statement to prevent from SQL injections 
                pstatement = connection.prepareStatement(deleteQuery);
                pstatement.setString(1, book_id);

                int deletedRow = pstatement.executeUpdate();

                if (deletedRow > 0) {
                    JOptionPane.showMessageDialog(this, "Book deleted successfully");
                    connection.close();
                    DisplayBooksTable();
                } else {
                    JOptionPane.showMessageDialog(this, "Error: Failed to delete book");
                }

            } catch (ClassNotFoundException | SQLException e) {
                System.out.println(e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.");
        }
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void categoriesFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_categoriesFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_categoriesFieldActionPerformed

    private void isbnFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isbnFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_isbnFieldActionPerformed

    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed
        // TODO add your handling code here:
        if (titleField.getText().isEmpty() || authorField.getText().isEmpty() || copiesField.getText().isEmpty() || categoriesField.getText().isEmpty() || isbnField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Fill out the required fields");
        } else {

            try {
                
                // check if the book already exist
                
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                connection = DriverManager.getConnection(dbURL);
                
                // check if the book already exist
                //String checkQuery = "SELECT COUNT(*) FROM Books WHERE title = ?, author = ?, copies = ?, category = ?, isbn = ?";
     
                String query = "INSERT INTO Books (title, author, copies, category, isbn) VALUES (?, ?, ?, ?, ?)";

                pstatement = connection.prepareStatement(query);

                pstatement.setString(1, titleField.getText());
                pstatement.setString(2, authorField.getText());
                pstatement.setInt(3, Integer.parseInt(copiesField.getText()));
                pstatement.setString(4, categoriesField.getText());
                pstatement.setString(5, isbnField.getText());

                int result = pstatement.executeUpdate();

                if (result > 0) {
                    insertCopiesID();
                    JOptionPane.showMessageDialog(this, "Books Added!");
                    connection.close();
                    DisplayBooksTable();

                }
            } catch (ClassNotFoundException | SQLException e) {
                System.out.println(e);
            }

        }
    }//GEN-LAST:event_saveBtnActionPerformed

    //int rowIndex = 0;
    private void bookTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bookTableMouseClicked
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel) bookTable.getModel();

//        int rowIndex = bookTable.getSelectedRow();
//        if (rowIndex != 1) {
////            int option = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this book?", "Confirmation", JOptionPane.YES_NO_OPTION);
////            // Yes Delete the selected row
////             if (option == JOptionPane.YES_OPTION) {
////                 //model.removeRow(bookTable.getSelectedRow());
////                 JOptionPane.showMessageDialog(this, "Book deleted Successfully");
////             } else {
////                 JOptionPane.showMessageDialog(this, "Book not deleted");
////             }
//        }
//        String title = model.getValueAt(bookTable.getSelectedRow(), 1).toString();
//        String author = model.getValueAt(bookTable.getSelectedRow(), 2).toString();
//        //String copies =  model.getValueAt(bookTable.getSelectedRow(), 3).toString();
//        
//        String categories = model.getValueAt(bookTable.getSelectedRow(), 4).toString();
//        String isbn = model.getValueAt(bookTable.getSelectedRow(), 5).toString();
//        
//        titleField.setText(title);
//        authorField.setText(author);
//        //copiesField = Integer.parseInt(copies);
//        categoriesField.setText(categories);
//        isbnField.setText(isbn);
    }//GEN-LAST:event_bookTableMouseClicked

    private void editBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editBtnActionPerformed
        // TODO add your handling code here:

        int editRow = bookTable.getSelectedRow();

        if (editRow != -1) {
            String book_id = bookTable.getValueAt(editRow, 0).toString();
            try {

                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                connection = DriverManager.getConnection(dbURL);

                String updateQuery = "UPDATE Books set title=?,author=?, copies=?, category=?, isbn=? WHERE bookid = ?";

                pstatement = connection.prepareStatement(updateQuery);
                pstatement.setString(1, titleField.getText());
                pstatement.setString(2, authorField.getText());
                pstatement.setString(3, copiesField.getText());
                pstatement.setString(4, categoriesField.getText());
                pstatement.setString(5, isbnField.getText());
                pstatement.setString(6, book_id);

                int editedRows = pstatement.executeUpdate();

                if (editedRows > 0) {
                    JOptionPane.showMessageDialog(this, "Book updated successfully");
                    connection.close();
                    DisplayBooksTable();
                } else {
                    JOptionPane.showMessageDialog(this, "Error: Failed to update row");
                }

            } catch (ClassNotFoundException | SQLException e) {
                System.out.println(e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to edit.");
        }
    }//GEN-LAST:event_editBtnActionPerformed

    // the variable for the number of copies 
    int availCopies = 1;

    private void insertCopiesID() {
        try {
            // get the auto generated key from the prepared statement
            ResultSet generatedKeys = pstatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                // Extract the bookId from the first generated key
                int book_id = generatedKeys.getInt(1);
                try {
                    // connect to the database
                    Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                    connection = DriverManager.getConnection(dbURL);

                    // Sql statement to book id into the copy table
                    String copyQuery = "INSERT INTO Copy (bid) VALUES (?)";

                    pstatement = connection.prepareStatement(copyQuery);
                    for (int i = 0; i < availCopies; i++) {
                        // setting book id position in the table
                        pstatement.setInt(1, book_id);
                        pstatement.executeUpdate();
                    }
                } catch (ClassNotFoundException | SQLException e) {
                    System.out.println(e);
                }
            }

        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                //new Librarian().setVisible(true);
                
                //new view().setVisible(true);
                
              //new lmsPage().setVisible(true);
              new studentPortal().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ManagePanel;
    private javax.swing.JTabbedPane Profile;
    private javax.swing.JLabel accountType_lbl;
    private javax.swing.JButton addImageBtn;
    private javax.swing.JTextField authorField;
    private javax.swing.JLabel authorlbl;
    private javax.swing.JTable bookTable;
    private javax.swing.JPanel borrowedPanel;
    private javax.swing.JTextField categoriesField;
    private javax.swing.JLabel categoriesLbl;
    private javax.swing.JTextField copiesField;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JButton editBtn;
    private javax.swing.JLabel emailLbl;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JLabel headerTitle;
    private javax.swing.JTextField isbnField;
    private javax.swing.JLabel isbnLabel;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel managelbl;
    private javax.swing.JLabel namelbl;
    private javax.swing.JLabel passwordLbl;
    private javax.swing.JLabel profileImagelbl;
    private javax.swing.JPanel profilePanel;
    private javax.swing.JButton saveBtn;
    private javax.swing.JTextField titleField;
    private javax.swing.JLabel titlelbl;
    // End of variables declaration//GEN-END:variables
}
