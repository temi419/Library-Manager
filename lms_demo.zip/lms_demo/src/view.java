
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.Date;

/**
 *
 * @author C20441194
 */
public class view extends javax.swing.JFrame {

    // Global variable for the database connection
    Connection connection = null;
    PreparedStatement pstatement = null, updatepst = null;
    Statement statement = null;
    ResultSet resultSet = null;
    String msAccDB = "//C://Users//orowo//Documents//LMS Database.accdb//";
    String dbURL = "jdbc:ucanaccess://" + msAccDB;

    private String email;

    public view() {
        initComponents();
        //DisplayBorrowedBooks();
        //manuallyRetrieveUserID(email);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        searchPanel = new javax.swing.JPanel();
        headerPanel = new javax.swing.JPanel();
        headerTitle = new javax.swing.JLabel();
        navbarPane = new javax.swing.JTabbedPane();
        searchBarPanel = new javax.swing.JPanel();
        searchTitle = new javax.swing.JLabel();
        searchField = new javax.swing.JTextField();
        searchIcon = new javax.swing.JLabel();
        searchBtn = new javax.swing.JButton();
        borrowedPanel = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        borrowedTbl = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        searchResultPanel = new javax.swing.JPanel();
        headerPanel1 = new javax.swing.JPanel();
        headerTitle1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        searchResultTbl = new javax.swing.JTable();
        borrowBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        headerPanel.setBackground(new java.awt.Color(51, 51, 51));

        headerTitle.setBackground(new java.awt.Color(255, 255, 255));
        headerTitle.setFont(new java.awt.Font("JetBrains Mono", 0, 18)); // NOI18N
        headerTitle.setForeground(new java.awt.Color(255, 255, 255));
        headerTitle.setText("Libary Management System");

        javax.swing.GroupLayout headerPanelLayout = new javax.swing.GroupLayout(headerPanel);
        headerPanel.setLayout(headerPanelLayout);
        headerPanelLayout.setHorizontalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addGap(305, 305, 305)
                .addComponent(headerTitle)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        headerPanelLayout.setVerticalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, headerPanelLayout.createSequentialGroup()
                .addContainerGap(33, Short.MAX_VALUE)
                .addComponent(headerTitle)
                .addGap(26, 26, 26))
        );

        navbarPane.setBackground(new java.awt.Color(204, 204, 204));

        searchTitle.setFont(new java.awt.Font("JetBrains Mono", 1, 18)); // NOI18N
        searchTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        searchTitle.setText("Search for Books and More");

        searchField.setFont(new java.awt.Font("JetBrains Mono", 1, 14)); // NOI18N
        searchField.setForeground(new java.awt.Color(204, 204, 204));
        searchField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        searchField.setText("Search for title, author, ISBN, category");
        searchField.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        searchField.setOpaque(true);
        searchField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchFieldFocusLost(evt);
            }
        });
        searchField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchFieldActionPerformed(evt);
            }
        });
        searchField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                searchFieldKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchFieldKeyReleased(evt);
            }
        });

        searchBtn.setBackground(new java.awt.Color(51, 51, 51));
        searchBtn.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        searchBtn.setForeground(new java.awt.Color(255, 255, 255));
        searchBtn.setText("Search");
        searchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout searchBarPanelLayout = new javax.swing.GroupLayout(searchBarPanel);
        searchBarPanel.setLayout(searchBarPanelLayout);
        searchBarPanelLayout.setHorizontalGroup(
            searchBarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchBarPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(searchIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(646, 646, 646))
            .addGroup(searchBarPanelLayout.createSequentialGroup()
                .addGroup(searchBarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(searchBarPanelLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(searchTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 765, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(searchBarPanelLayout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(103, Short.MAX_VALUE))
        );
        searchBarPanelLayout.setVerticalGroup(
            searchBarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchBarPanelLayout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(searchTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(searchIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(searchBarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(342, Short.MAX_VALUE))
        );

        navbarPane.addTab("Search", searchBarPanel);

        borrowedTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Copy ID", "Borrowed Date", "Due Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        borrowedTbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                borrowedTblMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(borrowedTbl);

        javax.swing.GroupLayout borrowedPanelLayout = new javax.swing.GroupLayout(borrowedPanel);
        borrowedPanel.setLayout(borrowedPanelLayout);
        borrowedPanelLayout.setHorizontalGroup(
            borrowedPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(borrowedPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 888, Short.MAX_VALUE)
                .addContainerGap())
        );
        borrowedPanelLayout.setVerticalGroup(
            borrowedPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(borrowedPanelLayout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(85, Short.MAX_VALUE))
        );

        navbarPane.addTab("Borrowed", borrowedPanel);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 575, Short.MAX_VALUE)
        );

        navbarPane.addTab("Profile", jPanel1);

        javax.swing.GroupLayout searchPanelLayout = new javax.swing.GroupLayout(searchPanel);
        searchPanel.setLayout(searchPanelLayout);
        searchPanelLayout.setHorizontalGroup(
            searchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(headerPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(navbarPane)
        );
        searchPanelLayout.setVerticalGroup(
            searchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchPanelLayout.createSequentialGroup()
                .addComponent(headerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(navbarPane))
        );

        searchResultPanel.setBackground(new java.awt.Color(255, 255, 255));
        searchResultPanel.setPreferredSize(new java.awt.Dimension(900, 700));

        headerPanel1.setBackground(new java.awt.Color(51, 51, 51));

        headerTitle1.setBackground(new java.awt.Color(255, 255, 255));
        headerTitle1.setFont(new java.awt.Font("JetBrains Mono", 0, 18)); // NOI18N
        headerTitle1.setForeground(new java.awt.Color(255, 255, 255));
        headerTitle1.setText("Libary Management System");

        javax.swing.GroupLayout headerPanel1Layout = new javax.swing.GroupLayout(headerPanel1);
        headerPanel1.setLayout(headerPanel1Layout);
        headerPanel1Layout.setHorizontalGroup(
            headerPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerPanel1Layout.createSequentialGroup()
                .addGap(305, 305, 305)
                .addComponent(headerTitle1)
                .addContainerGap(319, Short.MAX_VALUE))
        );
        headerPanel1Layout.setVerticalGroup(
            headerPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, headerPanel1Layout.createSequentialGroup()
                .addContainerGap(33, Short.MAX_VALUE)
                .addComponent(headerTitle1)
                .addGap(26, 26, 26))
        );

        searchResultTbl.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        searchResultTbl.setForeground(new java.awt.Color(102, 102, 102));
        searchResultTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title", "Author", "Available Copies", "Categories"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        searchResultTbl.setRowHeight(28);
        searchResultTbl.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(searchResultTbl);

        borrowBtn.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        borrowBtn.setText("Borrow");
        borrowBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borrowBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout searchResultPanelLayout = new javax.swing.GroupLayout(searchResultPanel);
        searchResultPanel.setLayout(searchResultPanelLayout);
        searchResultPanelLayout.setHorizontalGroup(
            searchResultPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchResultPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(searchResultPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(headerPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, searchResultPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(borrowBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41))
        );
        searchResultPanelLayout.setVerticalGroup(
            searchResultPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchResultPanelLayout.createSequentialGroup()
                .addComponent(headerPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(borrowBtn)
                .addGap(0, 98, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(searchPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(searchResultPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(searchPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(searchResultPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchFieldActionPerformed

    private void searchFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchFieldKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchFieldKeyPressed

    private void searchFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchFieldKeyReleased
        // TODO add your handling code here:
//        String search = searchField.getText().trim();
//        if (search.equals("")) {
//            System.out.print("Searching....");
//            menu.setVisible(true);
//            menu.show(searchField, 0, searchField.getHeight());
//            
//        }


    }//GEN-LAST:event_searchFieldKeyReleased

    private void searchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBtnActionPerformed
        // TODO add your handling code here:
        // TODO add your handling code here:
        if (searchField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "");
        } else {
            try {
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                connection = DriverManager.getConnection(dbURL);

                statement = connection.createStatement();

                String search = searchField.getText().trim();

                resultSet = statement.executeQuery("SELECT * From Books WHERE title LIKE '%" + search + "%' OR author LIKE '%" + search + "%'"
                        + "     OR copies LIKE '%" + search + "%' OR category LIKE '%" + search + "%'");

                int columns = resultSet.getMetaData().getColumnCount();

                DefaultTableModel model = (DefaultTableModel) searchResultTbl.getModel();
                model.setRowCount(0);

                while (resultSet.next()) {
                    Object[] row = new Object[columns];
                    row[0] = resultSet.getString("Title");
                    row[1] = resultSet.getString("Author");
                    row[2] = resultSet.getInt("Copies");
                    row[3] = resultSet.getString("Category");
                    model.addRow(row);

                    // this will make the search panel invisible
                    searchPanel.setVisible(false);

                    // Show the search results panel
                    searchResultPanel.setVisible(true);
                }

            } catch (ClassNotFoundException | SQLException e) {
                System.out.println(e);
            }
        }

    }//GEN-LAST:event_searchBtnActionPerformed

    private void searchFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchFieldFocusGained
        // TODO add your handling code here:
        if (searchField.getText().equals("Search for title, author, ISBN, category")) {
            searchField.setText("");
            searchField.setForeground(new Color(153, 153, 153));
        }

    }//GEN-LAST:event_searchFieldFocusGained

    private void searchFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchFieldFocusLost
        // TODO add your handling code here:
        if (searchField.getText().equals("")) {
            searchField.setText("Search for title, author, ISBN, category");
            searchField.setForeground(new Color(153, 153, 153));
        }
    }//GEN-LAST:event_searchFieldFocusLost

    private void borrowBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borrowBtnActionPerformed
        // TODO add your handling code here:
        int selectedBorrowRow = searchResultTbl.getSelectedRow();
        LocalDate borrowedDate = LocalDate.now();
        LocalDate dueDate = LocalDate.now().plusDays(28);
//       // String user_id = "";
//        
//        try {
//            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
//            connection = DriverManager.getConnection(dbURL);
//
//            String getUserid = "SELECT userID FROM User WHERE email = ?";
//
//            PreparedStatement pst = connection.prepareStatement(getUserid);
//            pst.setString(1, email);
//
//            resultSet = pst.executeQuery();
//
//            if (resultSet.next()) {
//                user_id = resultSet.getString("userID");
//            }
//
//        } catch (ClassNotFoundException | SQLException e) {
//            System.out.println(e);
//        }

        // Check if a row in the search Result table is selected
        if (selectedBorrowRow != -1) {
            // Starting connection
            String copy_id = searchResultTbl.getValueAt(selectedBorrowRow, 0).toString();

            try {
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                connection = DriverManager.getConnection(dbURL);

                String query = "INSERT INTO borrowed (borrowed_date, due_date, userID) VALUES (?, ?, ?)";

                pstatement = connection.prepareStatement(query);

                //pstatement.setString(1, copy_id);
                pstatement.setDate(1, Date.valueOf(borrowedDate));
                pstatement.setDate(2, Date.valueOf(dueDate));
                //pstatement.setString(3, user_id);

                int changedRows = pstatement.executeUpdate();

                // update the book table
                if (changedRows > 0) {
                    try {
                        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                         connection = DriverManager.getConnection(dbURL);

                        // Update the available in the database
                        String availableCopies = "UPDATE Books set copies = copies - 1 WHERE bookid = ?";
                        updatepst = connection.prepareStatement(availableCopies);

                        updatepst.setString(1, copy_id);
                        updatepst.executeUpdate();

                        JOptionPane.showMessageDialog(null, "Book borrowed successfully!");

                    } catch (ClassNotFoundException | SQLException e) {
                        System.out.println(e);
                    }

                }

            } catch (ClassNotFoundException | SQLException e) {
                System.out.println(e);
            }

        } else {
            JOptionPane.showMessageDialog(null, "Please select a row to borrow a book.");
        }

    }//GEN-LAST:event_borrowBtnActionPerformed

    private void borrowedTblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_borrowedTblMouseClicked

    }//GEN-LAST:event_borrowedTblMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(view.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(view.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(view.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(view.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new view().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton borrowBtn;
    private javax.swing.JPanel borrowedPanel;
    private javax.swing.JTable borrowedTbl;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JPanel headerPanel1;
    private javax.swing.JLabel headerTitle;
    private javax.swing.JLabel headerTitle1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane navbarPane;
    private javax.swing.JPanel searchBarPanel;
    private javax.swing.JButton searchBtn;
    private javax.swing.JTextField searchField;
    private javax.swing.JLabel searchIcon;
    private javax.swing.JPanel searchPanel;
    private javax.swing.JPanel searchResultPanel;
    private javax.swing.JTable searchResultTbl;
    private javax.swing.JLabel searchTitle;
    // End of variables declaration//GEN-END:variables
}
