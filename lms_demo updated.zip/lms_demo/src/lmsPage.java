
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.format.DateTimeFormatter;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class lmsPage extends javax.swing.JFrame {

    Connection connection = null;
    PreparedStatement pstatement = null, pstSelectStatement;
    Statement statement = null, statement1 = null;
    ResultSet resultSet = null, resultSet1 = null;
    String msAccDB = "//C://Users//orowo//Downloads//LMSDatabase.accdb//";
    String dbURL = "jdbc:ucanaccess://" + msAccDB;

    public lmsPage() {
        initComponents();
        DisplayBooksTable();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        headerPanel = new javax.swing.JPanel();
        headerTitle = new javax.swing.JLabel();
        sideBarPanel = new javax.swing.JPanel();
        menuBtn = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        managePanel = new javax.swing.JPanel();
        bookIcon = new javax.swing.JLabel();
        manageText = new javax.swing.JLabel();
        borrowPanel = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        logoutPanel = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        navbarPanel = new javax.swing.JTabbedPane();
        manageTab = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        manageBookLbl = new javax.swing.JLabel();
        titleLabel = new javax.swing.JLabel();
        copyLbl = new javax.swing.JLabel();
        titleLabel3 = new javax.swing.JLabel();
        isbnLbl = new javax.swing.JLabel();
        categoryLbl = new javax.swing.JLabel();
        searchField = new javax.swing.JTextField();
        titleField = new javax.swing.JTextField();
        authorField = new javax.swing.JTextField();
        copiesField = new javax.swing.JTextField();
        isbnField = new javax.swing.JTextField();
        categoryField = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        bookTable = new javax.swing.JTable();
        deleteBtn = new javax.swing.JLabel();
        saveBtn = new javax.swing.JLabel();
        editBtn = new javax.swing.JLabel();
        borrowedTab = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        manageBookLbl1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        borrowTbl = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setMinimumSize(new java.awt.Dimension(1080, 720));
        jPanel1.setPreferredSize(new java.awt.Dimension(1080, 720));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        headerPanel.setBackground(new java.awt.Color(35, 41, 70));

        headerTitle.setFont(new java.awt.Font("JetBrains Mono", 1, 18)); // NOI18N
        headerTitle.setForeground(new java.awt.Color(255, 255, 255));
        headerTitle.setText("Libary Management System");

        javax.swing.GroupLayout headerPanelLayout = new javax.swing.GroupLayout(headerPanel);
        headerPanel.setLayout(headerPanelLayout);
        headerPanelLayout.setHorizontalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(headerTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(637, Short.MAX_VALUE))
        );
        headerPanelLayout.setVerticalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(headerTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jPanel1.add(headerPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1080, 80));

        sideBarPanel.setBackground(new java.awt.Color(35, 41, 70));
        sideBarPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuBtn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        menuBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu_32px.png"))); // NOI18N
        menuBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        menuBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuBtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                menuBtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                menuBtnMouseExited(evt);
            }
        });
        sideBarPanel.add(menuBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 10, 50, 50));

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu_32px.png"))); // NOI18N
        sideBarPanel.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 10, 50, 50));

        managePanel.setBackground(new java.awt.Color(35, 41, 70));
        managePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                managePanelMouseClicked(evt);
            }
        });
        managePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bookIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        bookIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/books-32.png"))); // NOI18N
        managePanel.add(bookIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 50, 50));

        manageText.setFont(new java.awt.Font("JetBrains Mono", 1, 14)); // NOI18N
        manageText.setForeground(new java.awt.Color(255, 255, 255));
        manageText.setText("Manage Books");
        managePanel.add(manageText, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 120, -1));

        sideBarPanel.add(managePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 210, 50));

        borrowPanel.setBackground(new java.awt.Color(35, 41, 70));
        borrowPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                borrowPanelMouseClicked(evt);
            }
        });
        borrowPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/borrow-book-32.png"))); // NOI18N
        borrowPanel.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 50, 50));

        jLabel8.setFont(new java.awt.Font("JetBrains Mono", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Borrow");
        borrowPanel.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 120, -1));

        sideBarPanel.add(borrowPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 210, 50));

        logoutPanel.setBackground(new java.awt.Color(35, 41, 70));
        logoutPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutPanelMouseClicked(evt);
            }
        });
        logoutPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/logout-32.png"))); // NOI18N
        logoutPanel.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 50, 50));

        jLabel10.setFont(new java.awt.Font("JetBrains Mono", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Logout");
        logoutPanel.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 120, -1));

        sideBarPanel.add(logoutPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, 210, 50));

        jPanel1.add(sideBarPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 73, 210, 645));

        navbarPanel.setRequestFocusEnabled(false);

        manageTab.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        manageTab.setFont(new java.awt.Font("JetBrains Mono", 0, 12)); // NOI18N

        jPanel5.setBackground(new java.awt.Color(153, 153, 153));
        jPanel5.setDoubleBuffered(false);
        jPanel5.setOpaque(false);

        manageBookLbl.setFont(new java.awt.Font("JetBrains Mono", 1, 14)); // NOI18N
        manageBookLbl.setForeground(new java.awt.Color(51, 51, 51));
        manageBookLbl.setText("Manage Books");

        titleLabel.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        titleLabel.setText("Title");

        copyLbl.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        copyLbl.setText("Copies");

        titleLabel3.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        titleLabel3.setText("Author");

        isbnLbl.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        isbnLbl.setText("ISBN");

        categoryLbl.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        categoryLbl.setText("Category");

        searchField.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N
        searchField.setText("Search");
        searchField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchFieldFocusLost(evt);
            }
        });
        searchField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchFieldActionPerformed(evt);
            }
        });

        titleField.setFont(new java.awt.Font("JetBrains Mono", 0, 12)); // NOI18N
        titleField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                titleFieldActionPerformed(evt);
            }
        });

        authorField.setFont(new java.awt.Font("JetBrains Mono", 0, 12)); // NOI18N
        authorField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                authorFieldActionPerformed(evt);
            }
        });

        copiesField.setFont(new java.awt.Font("JetBrains Mono", 0, 12)); // NOI18N
        copiesField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copiesFieldActionPerformed(evt);
            }
        });

        isbnField.setFont(new java.awt.Font("JetBrains Mono", 0, 12)); // NOI18N
        isbnField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isbnFieldActionPerformed(evt);
            }
        });

        categoryField.setFont(new java.awt.Font("JetBrains Mono", 0, 12)); // NOI18N
        categoryField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                categoryFieldActionPerformed(evt);
            }
        });

        jScrollPane1.setBackground(new java.awt.Color(18, 22, 41));

        bookTable.setAutoCreateRowSorter(true);
        bookTable.setBackground(new java.awt.Color(51, 51, 51));
        bookTable.setFont(new java.awt.Font("JetBrains Mono", 0, 12)); // NOI18N
        bookTable.setForeground(new java.awt.Color(255, 255, 255));
        bookTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Index", "Title", "Author", "Category", "Copies", "ISBN"
            }
        ));
        bookTable.setFocusable(false);
        bookTable.setRowHeight(28);
        bookTable.setShowGrid(true);
        bookTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(bookTable);

        deleteBtn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        deleteBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/delete-32.png"))); // NOI18N
        deleteBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteBtnMouseClicked(evt);
            }
        });

        saveBtn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        saveBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/plus-32.png"))); // NOI18N
        saveBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                saveBtnMouseClicked(evt);
            }
        });

        editBtn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        editBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/edit-32.png"))); // NOI18N
        editBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editBtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(titleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(copiesField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                                        .addComponent(titleField, javax.swing.GroupLayout.Alignment.LEADING))
                                    .addComponent(copyLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(authorField, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(titleLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(categoryLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel5Layout.createSequentialGroup()
                                                .addComponent(categoryField, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(104, 104, 104)
                                                .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(isbnLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(isbnField, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(saveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(editBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(55, 55, 55))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(375, 375, 375)
                .addComponent(manageBookLbl)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(manageBookLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(titleLabel)
                    .addComponent(titleLabel3)
                    .addComponent(categoryLbl))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(titleField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(authorField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(categoryField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(copyLbl)
                                    .addComponent(isbnLbl))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(copiesField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(isbnField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(saveBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(deleteBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addComponent(editBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout manageTabLayout = new javax.swing.GroupLayout(manageTab);
        manageTab.setLayout(manageTabLayout);
        manageTabLayout.setHorizontalGroup(
            manageTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        manageTabLayout.setVerticalGroup(
            manageTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        navbarPanel.addTab("Manage books", manageTab);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        manageBookLbl1.setFont(new java.awt.Font("JetBrains Mono", 1, 14)); // NOI18N
        manageBookLbl1.setForeground(new java.awt.Color(51, 51, 51));
        manageBookLbl1.setText("Borrowed Books");

        borrowTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Book Title", "Borrower", "Borrowed Date", "Due Date"
            }
        ));
        jScrollPane2.setViewportView(borrowTbl);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(manageBookLbl1)
                        .addGap(386, 386, 386))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 816, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(manageBookLbl1)
                .addGap(26, 26, 26)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 509, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(49, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout borrowedTabLayout = new javax.swing.GroupLayout(borrowedTab);
        borrowedTab.setLayout(borrowedTabLayout);
        borrowedTabLayout.setHorizontalGroup(
            borrowedTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        borrowedTabLayout.setVerticalGroup(
            borrowedTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        navbarPanel.addTab("tab2", borrowedTab);

        jPanel1.add(navbarPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 40, 870, 680));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    int x = 210;
    private void menuBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuBtnMouseClicked
        if (x == 210) {
            sideBarPanel.setSize(210, 645);
            Thread th = new Thread() {
                @Override
                public void run() {
                    try {
                        for (int i = 210; i >= 0; i++) {
                            sideBarPanel.setSize(1, 645);
                        }
                    } catch (Exception er) {
                        JOptionPane.showMessageDialog(null, er);
                    }
                }
            };
            th.start();
            x = 0;
        }
    }//GEN-LAST:event_menuBtnMouseClicked

    private void menuBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuBtnMouseEntered
        labelColor(menuBtn);
    }//GEN-LAST:event_menuBtnMouseEntered

    private void menuBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuBtnMouseExited
        resetLabelColor(menuBtn);
    }//GEN-LAST:event_menuBtnMouseExited

    private void managePanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_managePanelMouseClicked
        navbarPanel.setSelectedIndex(0);
    }//GEN-LAST:event_managePanelMouseClicked

    private void searchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchFieldActionPerformed

    private void titleFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_titleFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_titleFieldActionPerformed

    private void authorFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_authorFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_authorFieldActionPerformed

    private void copiesFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copiesFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_copiesFieldActionPerformed

    private void isbnFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isbnFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_isbnFieldActionPerformed

    private void categoryFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_categoryFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_categoryFieldActionPerformed

    private void borrowPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_borrowPanelMouseClicked
        navbarPanel.setSelectedIndex(1);

        try {
            DefaultTableModel borrowedModel = (DefaultTableModel) borrowTbl.getModel();
            borrowedModel.setRowCount(0);

            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            connection = DriverManager.getConnection(dbURL);

            String borrowQuery = "SELECT b.title, u.name AS borrower, br.borrowed_date, br.due_date "
                    + "FROM Books b "
                    + "JOIN copy c ON b.bookid = c.bid "
                    + "JOIN borrowed br ON c.copyID = br.copyID "
                    + "JOIN User u ON br.userID = u.userID";

            pstatement = connection.prepareStatement(borrowQuery);

            resultSet = pstatement.executeQuery();

            int columns = resultSet.getMetaData().getColumnCount();
            while (resultSet.next()) {
                Object[] row = new Object[columns];
                row[0] = resultSet.getObject("title");
                row[1] = resultSet.getObject("name");
                row[2] = resultSet.getDate("borrowed_date").toLocalDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));; // Use getInt for integer values
                row[3] = resultSet.getDate("due_date").toLocalDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));;
                //row[5] = resultSet.getObject("remaining");
                borrowedModel.addRow(row);
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }


    }//GEN-LAST:event_borrowPanelMouseClicked

    private void deleteBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteBtnMouseClicked
        int deleteRow = bookTable.getSelectedRow();

        // Check row is selected
        if (deleteRow != -1) {
            String book_id = bookTable.getValueAt(deleteRow, 0).toString();

            try {
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                connection = DriverManager.getConnection(dbURL);

                String deleteQuery = "DELETE FROM Books WHERE bookid IN (SELECT bid FROM Copy)";
                // Use prepared statement to prevent from SQL injections 
                pstatement = connection.prepareStatement(deleteQuery);
                pstatement.setString(1, book_id);
                

                int deletedRow = pstatement.executeUpdate();

                if (deletedRow > 0) {
                    JOptionPane.showMessageDialog(this, "Book deleted successfully");
                    connection.close();
                    DisplayBooksTable();
                } else {
                    JOptionPane.showMessageDialog(this, "Error: Failed to delete book");
                }

            } catch (ClassNotFoundException | SQLException e) {
                System.out.println(e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.");
        }

    }//GEN-LAST:event_deleteBtnMouseClicked

    private void saveBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_saveBtnMouseClicked
        if (titleField.getText().isEmpty() || authorField.getText().isEmpty() || copiesField.getText().isEmpty() || categoryField.getText().isEmpty() || isbnField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Fill out the required fields");
        } else {

            try {

                // check if the book already exist
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                connection = DriverManager.getConnection(dbURL);

                String check = "SELECT COUNT(*) FROM Books WHERE title = ? AND author = ? AND copies = ? AND category = ? AND isbn = ?";

                pstSelectStatement = connection.prepareStatement(check);
                pstSelectStatement.setString(1, titleField.getText());
                pstSelectStatement.setString(2, authorField.getText());
                pstSelectStatement.setInt(3, Integer.parseInt(copiesField.getText()));
                pstSelectStatement.setString(4, categoryField.getText());
                pstSelectStatement.setString(5, isbnField.getText());

                resultSet = pstSelectStatement.executeQuery();

                if (resultSet.next()) {
                    int checkDatabase = resultSet.getInt(1);

                    if (checkDatabase > 0) {
                        JOptionPane.showMessageDialog(this, "This Book already exists in the database");
                    } else {
                        String query = "INSERT INTO Books (title, author, copies, category, isbn) VALUES (?, ?, ?, ?, ?)";

                        pstatement = connection.prepareStatement(query);

                        pstatement.setString(1, titleField.getText());
                        pstatement.setString(2, authorField.getText());
                        //pstatement.setInt(3, Integer.parseInt(copiesField.getText()));
                        pstatement.setString(3, copiesField.getText());
                        pstatement.setString(4, categoryField.getText());
                        pstatement.setString(5, isbnField.getText());

                        int result = pstatement.executeUpdate();

                        if (result > 0) {
                            insertCopiesID();
                            JOptionPane.showMessageDialog(this, "Books Added!");
                            DisplayBooksTable();
                            clearTextFields();
                        }
                    }

                }

                connection.close();
            } catch (ClassNotFoundException | SQLException e) {
                System.out.println(e);
            }

        }

    }//GEN-LAST:event_saveBtnMouseClicked

    private void editBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editBtnMouseClicked
        int editRow = bookTable.getSelectedRow();

        if (editRow != -1) {
            String book_id = bookTable.getValueAt(editRow, 0).toString();

//            titleField.setText(bookTable.getValueAt(editRow, 1).toString());
//            authorField.setText(bookTable.getValueAt(editRow, 2).toString());
//            copiesField.setText(bookTable.getValueAt(editRow, 3).toString());
//            categoryField.setText(bookTable.getValueAt(editRow, 4).toString());
//            isbnField.setText(bookTable.getValueAt(editRow, 5).toString());

            //int copies = Integer.parseInt(copiesField.getText());
            try {

                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                connection = DriverManager.getConnection(dbURL);

                String updateQuery = "UPDATE Books set title=?,author=?, copies=?, category=?, isbn=? WHERE bookid = ?";

                pstatement = connection.prepareStatement(updateQuery);
                pstatement.setString(1, titleField.getText());
                pstatement.setString(2, authorField.getText());
                pstatement.setString(3, copiesField.getText());
                pstatement.setString(4, categoryField.getText());
                pstatement.setString(5, isbnField.getText());
                pstatement.setString(6, book_id);

                int editedRows = pstatement.executeUpdate();

                if (editedRows > 0) {
                    JOptionPane.showMessageDialog(this, "Book updated successfully");
                    //connection.close();
                    // Display the new updated table
                    DisplayBooksTable();
                    // Clear text field after clicking on the update button
                    clearTextFields();
                } else {
                    JOptionPane.showMessageDialog(this, "Error: Failed to update row");
                }

            } catch (ClassNotFoundException | SQLException e) {
                System.out.println(e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to edit.");
        }
    }//GEN-LAST:event_editBtnMouseClicked

    private void searchFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchFieldFocusGained
        if (searchField.getText().equals("Search")) {
            searchField.setText("");
            searchField.setForeground(new Color(153, 153, 153));
        }
    }//GEN-LAST:event_searchFieldFocusGained

    private void searchFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchFieldFocusLost
        if (searchField.getText().equals("")) {
            searchField.setText("Search");
            searchField.setForeground(new Color(153, 153, 153));
        }
    }//GEN-LAST:event_searchFieldFocusLost

    private void logoutPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutPanelMouseClicked
        setVisible(false);
        new Loginpage().setVisible(true);
        JOptionPane.showMessageDialog(this, "You are not logged out successfully!!!");
    }//GEN-LAST:event_logoutPanelMouseClicked

    // Display the content of the database in a table format
    private void DisplayBooksTable() {
        try {
            DefaultTableModel model = (DefaultTableModel) bookTable.getModel();
            model.setRowCount(0);

            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            connection = DriverManager.getConnection(dbURL);

            statement = connection.createStatement();

            resultSet = statement.executeQuery("SELECT * FROM Books");

            int columns = resultSet.getMetaData().getColumnCount();
            while (resultSet.next()) {
                Object[] row = new Object[columns];
                row[0] = resultSet.getObject("bookid");
                row[1] = resultSet.getObject("title");
                row[2] = resultSet.getObject("author");
                row[3] = resultSet.getObject("category"); // Use getInt for integer values
                row[4] = resultSet.getInt("copies");
                row[5] = resultSet.getObject("isbn");
                model.addRow(row);
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
    }

    int availCopies = 1;

    // Method to insert copy id for available copies a book has
    private void insertCopiesID() {
        try {
            // get the auto generated key from the prepared statement
            ResultSet generatedKeys = pstatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                // Extract the bookId from the first generated key
                int book_id = generatedKeys.getInt(1);
                try {
                    // connect to the database
                    Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                    connection = DriverManager.getConnection(dbURL);

                    // Sql statement to book id into the copy table
                    String copyQuery = "INSERT INTO Copy (bid) VALUES (?)";

                    pstatement = connection.prepareStatement(copyQuery);
                    for (int i = 0; i < availCopies; i++) {
                        // setting book id position in the table
                        pstatement.setInt(1, book_id);
                        pstatement.executeUpdate();
                    }
                } catch (ClassNotFoundException | SQLException e) {
                    System.out.println(e);
                }
            }

        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    // Method to clear the textfield
    private void clearTextFields() {
        // Clear the text fields after successfully adding the book
        titleField.setText("");
        authorField.setText("");
        copiesField.setText("");
        categoryField.setText("");
        isbnField.setText("");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(lmsPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(lmsPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(lmsPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(lmsPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new lmsPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField authorField;
    private javax.swing.JLabel bookIcon;
    private javax.swing.JTable bookTable;
    private javax.swing.JPanel borrowPanel;
    private javax.swing.JTable borrowTbl;
    private javax.swing.JPanel borrowedTab;
    private javax.swing.JTextField categoryField;
    private javax.swing.JLabel categoryLbl;
    private javax.swing.JTextField copiesField;
    private javax.swing.JLabel copyLbl;
    private javax.swing.JLabel deleteBtn;
    private javax.swing.JLabel editBtn;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JLabel headerTitle;
    private javax.swing.JTextField isbnField;
    private javax.swing.JLabel isbnLbl;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel logoutPanel;
    private javax.swing.JLabel manageBookLbl;
    private javax.swing.JLabel manageBookLbl1;
    private javax.swing.JPanel managePanel;
    private javax.swing.JPanel manageTab;
    private javax.swing.JLabel manageText;
    private javax.swing.JLabel menuBtn;
    private javax.swing.JTabbedPane navbarPanel;
    private javax.swing.JLabel saveBtn;
    private javax.swing.JTextField searchField;
    private javax.swing.JPanel sideBarPanel;
    private javax.swing.JTextField titleField;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JLabel titleLabel3;
    // End of variables declaration//GEN-END:variables

    private void labelColor(JLabel label) {
        label.setBackground(new Color(18, 22, 41));
    }

    private void resetLabelColor(JLabel label) {
        label.setBackground(new Color(35, 41, 70));
    }

}
